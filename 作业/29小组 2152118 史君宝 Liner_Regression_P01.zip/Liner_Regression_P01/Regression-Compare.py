"""
    不同线性回归模型的对比
"""

import pandas as pd

data = pd.read_csv('Student_Performance.csv')
data = pd.get_dummies(data, columns=['Extracurricular Activities'], drop_first=True, dtype=int)

x = data.drop('Performance Index', axis=1)
y = data['Performance Index']

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1)

from sklearn.metrics import mean_squared_error, r2_score

# 导入所需的回归模型
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor

# 创建回归模型的实例
models = {
    'Linear Regression': LinearRegression(),
    'Lasso Regression': Lasso(),
    'Ridge Regression': Ridge(),
    'Support Vector Machine': SVR(),
    'K-Nearest Neighbors': KNeighborsRegressor(),
    'Decision Tree': DecisionTreeRegressor(),
    'Random Forest': RandomForestRegressor(),
    'AdaBoost': AdaBoostRegressor(),
    'Gradient Boosting': GradientBoostingRegressor()
}

# 训练和评估每个模型
for model_name, model in models.items():
    # Fit the model to the training data
    model.fit(x_train, y_train)

    # Make predictions on the test data
    predictions = model.predict(x_test)

    # Calculate Mean Squared Error (MSE) and R-squared (R2) for evaluation
    mse = mean_squared_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    print(f"Model: {model_name}")
    print(f"Mean Squared Error (MSE): {mse:.2f}")
    print(f"R-squared (R2): {r2:.2f}")

    if model_name == 'Linear Regression':
        # Access the model's coefficients and intercept
        coefficients = model.coef_
        intercept = model.intercept_

        print("Coefficients:", coefficients)
        print("Intercept:", intercept)

    print("\n")



