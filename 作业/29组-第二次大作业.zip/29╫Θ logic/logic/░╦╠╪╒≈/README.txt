accuracy_epochs.pdf   是反映在验证集上正确率随训练轮次的变化情况

data_matrix.pdf            是混淆矩阵

percent_prediction.pdf 是预测概率曲线，即在验证集上预测的概率的分布情况，其上的点是大于某预测概率的样本占所有样本的比例

ROC.pdf            是ROC曲线，越往上凸，即靠近左上角分类效果越好

weights_importance.pdf   训练结束后各特征系数对预测结果的重要性